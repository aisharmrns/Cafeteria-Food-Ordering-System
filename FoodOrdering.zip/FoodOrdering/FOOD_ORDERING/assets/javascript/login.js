document.getElementById("login-form").addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    // 🔄 Get all users (array)
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // ✅ Find a matching user
    const foundUser = users.find(user => user.email === email && user.password === password);

    if (!foundUser) {
        alert("Invalid email or password.");
        return;
    }

    // ✅ Save login session
    localStorage.setItem("loggedInUser", JSON.stringify({
        name: foundUser.name,
        email: foundUser.email,
        role: foundUser.role
    }));

    alert(`Logged in as ${foundUser.role}`);
    window.location.href = "index.html";
    if (foundUser.role === "admin") {
        window.location.href = "admin-home.html";
    } else {
        window.location.href = "index.html";
    }
});
