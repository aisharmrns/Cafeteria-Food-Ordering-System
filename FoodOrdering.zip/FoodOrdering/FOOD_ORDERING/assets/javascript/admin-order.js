let orders = JSON.parse(localStorage.getItem("orders")) || [
    { id: "#001", customer: "John Doe", items: ["Pizza", "Fries"], status: "Pending" },
    { id: "#002", customer: "Jane Smith", items: ["Burger"], status: "In Progress" }
  ];
  
  function renderOrders() {
    const table = document.getElementById("order-table-body");
    table.innerHTML = "";
    orders.forEach((order, index) => {
      table.innerHTML += `
        <tr>
          <td>${order.id}</td>
          <td>${order.customer}</td>
          <td>${order.items.join(", ")}</td>
          <td>
            <select onchange="updateOrderStatus(${index}, this.value)">
              <option ${order.status === "Pending" ? "selected" : ""}>Pending</option>
              <option ${order.status === "In Progress" ? "selected" : ""}>In Progress</option>
              <option ${order.status === "Delivered" ? "selected" : ""}>Delivered</option>
            </select>
          </td>
          <td><button onclick="saveOrders()">Save</button></td>
        </tr>
      `;
    });
  }
  
  function updateOrderStatus(index, newStatus) {
    orders[index].status = newStatus;
  }
  
  function saveOrders() {
    localStorage.setItem("orders", JSON.stringify(orders));
    alert("Order statuses updated!");
  }
  
  document.addEventListener("DOMContentLoaded", renderOrders);
  