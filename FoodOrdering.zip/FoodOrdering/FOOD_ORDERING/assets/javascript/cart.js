/*document.addEventListener("DOMContentLoaded", function () {
    fetch('cart.php')
        .then(response => response.json())
        .then(data => {
            let cartContainer = document.getElementById('cart-items');
            cartContainer.innerHTML = '';
            data.forEach(item => {
                let div = document.createElement('div');
                div.classList.add('card');
                div.innerHTML = `
                    <h3>${item.name}</h3>
                    <p>Price: $${item.price}</p>
                    <p>Quantity: ${item.quantity}</p>
                    <button onclick="removeFromCart(${item.id})">Remove</button>
                `;
                cartContainer.appendChild(div);
            });
        });
});

function removeFromCart(itemId) {
    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `item_id=${itemId}&remove=1`
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        location.reload();
    });
}

function checkout() {
    fetch('checkout.php', { method: 'POST' })
    .then(response => response.text())
    .then(data => {
        alert(data);
        location.href = "order-confirmation.html";
    });
}*/

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function renderCart() {
    const cartItemsContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");
    cartItemsContainer.innerHTML = "";
    let total = 0;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `<tr><td colspan="4">Your cart is empty.</td></tr>`;
    }

    cart.forEach((item, index) => {
        const subtotal = item.price * item.quantity;
        total += subtotal;

        cartItemsContainer.innerHTML += `
            <tr>
                <td>${item.name}</td>
                <td>
                    <button class="quantity-btn" onclick="changeQty(${index}, -1)">-</button>
                    ${item.quantity}
                    <button class="quantity-btn" onclick="changeQty(${index}, 1)">+</button>
                </td>
                <td>RM${subtotal.toFixed(2)}</td>
                <td><button class="remove-btn" onclick="removeItem(${index})">Remove</button></td>
            </tr>
        `;
    });

    totalPriceElement.innerText = total.toFixed(2);
}

function changeQty(index, change) {
    if (cart[index].quantity + change > 0) {
        cart[index].quantity += change;
    } else {
        cart.splice(index, 1);
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
}

function removeItem(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
}

function proceedToCheckout() {
    window.location.href = "checkout.html";
}

document.addEventListener("DOMContentLoaded", renderCart);
