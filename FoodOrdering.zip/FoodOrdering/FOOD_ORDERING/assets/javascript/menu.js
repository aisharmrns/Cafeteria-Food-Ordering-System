let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(name, price) {
    const existingItem = cart.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }

    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${name} added to cart!`);
}

document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".menu-item button");

    buttons.forEach(button => {
        button.addEventListener("click", () => {
            const item = button.closest(".menu-item");
            const name = item.querySelector("h3").innerText;
            const price = parseFloat(item.querySelector("span").innerText.replace("RM", ""));
            addToCart(name, price);
        });
    });
    const searchInput = document.getElementById("search");
    searchInput.addEventListener("input", function () {
        const keyword = this.value.toLowerCase();
        const items = document.querySelectorAll(".menu-item");

        items.forEach(item => {
            const name = item.querySelector("h3").innerText.toLowerCase();
            const desc = item.querySelector("p")?.innerText.toLowerCase() || "";
            if (name.includes(keyword) || desc.includes(keyword)) {
                item.style.display = "block";
            } else {
                item.style.display = "none";
            }
        });
    });
});
