let menu = JSON.parse(localStorage.getItem("menu")) || [
    { name: "Cheese Burger", price: 5.99 },
    { name: "Pepperoni Pizza", price: 12.0 }
  ];
  
  function renderMenu() {
    const body = document.getElementById("menu-body");
    body.innerHTML = "";
    menu.forEach((item, index) => {
      body.innerHTML += `
        <tr>
          <td><input type="text" value="${item.name}" onchange="updateName(${index}, this.value)"></td>
          <td><input type="number" step="0.01" value="${item.price}" onchange="updatePrice(${index}, this.value)"></td>
          <td><button onclick="deleteItem(${index})">Delete</button></td>
        </tr>
      `;
    });
  }
  
  function updateName(index, newName) {
    menu[index].name = newName;
    saveMenu();
  }
  
  function updatePrice(index, newPrice) {
    menu[index].price = parseFloat(newPrice);
    saveMenu();
  }
  
  function deleteItem(index) {
    if (confirm("Are you sure you want to delete this item?")) {
      menu.splice(index, 1);
      saveMenu();
      renderMenu();
    }
  }
  
  function addItem() {
    const name = prompt("Enter item name:");
    const price = prompt("Enter item price:");
    if (name && price) {
      menu.push({ name, price: parseFloat(price) });
      saveMenu();
      renderMenu();
    }
  }
  
  function saveMenu() {
    localStorage.setItem("menu", JSON.stringify(menu));
  }
  
  document.addEventListener("DOMContentLoaded", renderMenu);
  