document.getElementById("register-form").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const role = document.getElementById("role").value;
    const password = document.getElementById("password").value;
    const confirm = document.getElementById("confirm").value;

    if (!role) {
        alert("Please select a role.");
        return;
    }

    if (password !== confirm) {
        alert("Passwords do not match!");
        return;
    }

    // Save user data (frontend only, replace with PHP later)
    const newUser = {
        name,
        email,
        phone,
        role,
        password,
    };

    // Get existing users or empty array
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Check if email already exists
    const exists = users.some(user => user.email === email);
    if (exists) {
        alert("Email already registered!");
        return;
    }

    // Add new user
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registration successful! You can now log in.");
    window.location.href = "login.html";
});
