/*function showConfirmation() {
    const modal = document.getElementById("order-modal");
    if (modal) {
        modal.style.display = "flex";
        localStorage.removeItem("cart");
    }
}*/

function showConfirmation() {
    localStorage.removeItem("cart"); // Clear cart
    window.location.href = "order-confirmation.html"; // Go to status page
}


/*window.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("order-modal");
    if (modal) {
        modal.style.display = "none";
    }
});*/

function showConfirmation() {
    const modal = document.getElementById("order-modal");
    if (modal) {
        modal.style.display = "flex";
        localStorage.removeItem("cart");

        setTimeout(() => {
            window.location.href = "order-confirmation.html";
        }, 3000); // Wait 3 seconds then redirect
    }
}

