function handleOrder() {
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    if (user && user.role === "user") {
        window.location.href = "menu.html";
    } else if (user && user.role === "admin") {
        alert("Admins cannot place orders.");
    } else {
        alert("Please log in to place an order.");
        window.location.href = "index.html";
    }
}

function logout() {
    localStorage.removeItem("loggedInUser");
    alert("You have been logged out.");
    window.location.href = "login.html";
}
