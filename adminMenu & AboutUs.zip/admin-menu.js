/*let menu = JSON.parse(localStorage.getItem("menu")) || [
    { name: "Cheese Burger", price: 5.99 },
    { name: "Pepperoni Pizza", price: 12.0 }
  ];
  
  function renderMenu() {
    const body = document.getElementById("menu-body");
    body.innerHTML = "";
    menu.forEach((item, index) => {
      body.innerHTML += `
        <tr>
          <td><input type="text" value="${item.name}" onchange="updateName(${index}, this.value)"></td>
          <td><input type="number" step="0.01" value="${item.price}" onchange="updatePrice(${index}, this.value)"></td>
          <td><button onclick="deleteItem(${index})">Delete</button></td>
        </tr>
      `;
    });
  }
  
  function updateName(index, newName) {
    menu[index].name = newName;
    saveMenu();
  }
  
  function updatePrice(index, newPrice) {
    menu[index].price = parseFloat(newPrice);
    saveMenu();
  }
  
  function deleteItem(index) {
    if (confirm("Are you sure you want to delete this item?")) {
      menu.splice(index, 1);
      saveMenu();
      renderMenu();
    }
  }
  
  function addItem() {
    const name = prompt("Enter item name:");
    const price = prompt("Enter item price:");
    if (name && price) {
      menu.push({ name, price: parseFloat(price) });
      saveMenu();
      renderMenu();
    }
  }
  
  function saveMenu() {
    localStorage.setItem("menu", JSON.stringify(menu));
  }
  
  document.addEventListener("DOMContentLoaded", renderMenu);  */

  let menu = JSON.parse(localStorage.getItem("menu")) || [];

    function renderMenu() {
      const tbody = document.getElementById("menu-body");
      tbody.innerHTML = "";
      menu.forEach((item, index) => {
        tbody.innerHTML += `
          <tr>
            <td><img src="${item.image || 'assets/img/placeholder.png'}" width="80" height="60" style="object-fit:cover; border-radius:6px;"></td>
            <td><input type="text" value="${item.name}" onchange="updateName(${index}, this.value)"></td>
            <td><input type="number" value="${item.price}" onchange="updatePrice(${index}, this.value)"></td>
            <td>
              <button onclick="changeImage(${index})">Change Image</button>
              <button onclick="deleteItem(${index})">Delete</button>
            </td>
          </tr>
        `;
      });
    }

    function updateName(index, value) {
      menu[index].name = value;
      saveMenu();
    }

    function updatePrice(index, value) {
      menu[index].price = parseFloat(value);
      saveMenu();
    }

    function deleteItem(index) {
      menu.splice(index, 1);
      saveMenu();
      renderMenu();
    }

    function changeImage(index) {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => {
        const file = input.files[0];
        const reader = new FileReader();
        reader.onload = () => {
          menu[index].image = reader.result;
          saveMenu();
          renderMenu();
        };
        reader.readAsDataURL(file);
      };
      input.click();
    }

    function addItem() {
      const name = prompt("Enter food name:");
      const price = prompt("Enter price:");
      if (name && price) {
        menu.push({ name, price: parseFloat(price), image: "" });
        saveMenu();
        renderMenu();
      }
    }

    function saveMenu() {
      localStorage.setItem("menu", JSON.stringify(menu));
    }

    function logout() {
      localStorage.removeItem("loggedInUser");
      window.location.href = "login.html";
    }

    document.addEventListener("DOMContentLoaded", renderMenu);
  
  